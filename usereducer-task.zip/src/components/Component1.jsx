import React from 'react'

const Component1 = () => {
  return (
    <div style={{margin: "30px", padding:"30px", border: "1px solid black", backgroundColor: "lightblue"}}>
        <h3>Component1</h3>
    </div>
  )
}

export default Component1