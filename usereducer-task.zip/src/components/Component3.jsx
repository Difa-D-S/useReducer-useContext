import React from 'react'

const Component3 = () => {
  return (
    <div style={{margin: "30px", padding:"30px", border: "1px solid black", backgroundColor: "lightblue"}}>
        <h4>Component3</h4>
    </div>
  )
}

export default Component3